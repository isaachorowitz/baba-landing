export const ANIMATION = {
  SPIN_INTERVAL: 6000,    // Changed to 6 seconds
  SPIN_DURATION: 800,     // Smooth transition duration
  FADE_DURATION: 400,     // Text fade duration
} as const;